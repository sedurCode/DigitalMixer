 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\58\\71\\5871052\\4\Eagle\2018-11-14_03-26-01\2018-11-14_03-26-01.xml
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Component "CGA4C2C0G1H103J060AA" renamed to "CGA4C2C0G1H103J060AA"
Component "C2012X5R1V226M125AC" renamed to "C2012X5R1V226M125AC"
Component "C0805C106K8PACTU" renamed to "C0805C106K8PACTU"
Component "LM2736XMK/NOPB" renamed to "LM2736XMK/NOPB"
Component "SRN3015-6R8M" renamed to "SRN3015-6R8M"
Component "RC0201FR-0710KL" renamed to "RC0201FR-0710KL"
Component "CRCW040234K0FKED" renamed to "CRCW040234K0FKED"
Component "TP-5012" renamed to "TP-5012"
Component "MBR1020VL" renamed to "MBR1020VL"


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX44Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX53p37Y106p3D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX14Y13D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX48Y21D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "R10470470000202A" Shape(4) is a CIRCLE with no diameter.
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "CGA4C2C0G1H103J060AA" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4C2C0G1H103J060AA" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4C2C0G1H103J060AA" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4C2C0G1H103J060AA" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CGA4C2C0G1H103J060AA" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1V226M125AC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM2736XMK/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM2736XMK/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM2736XMK/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM2736XMK/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM2736XMK/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM2736XMK/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN3015-6R8M" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN3015-6R8M" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN3015-6R8M" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "SRN3015-6R8M" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040234K0FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040234K0FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040234K0FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MBR1020VL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MBR1020VL" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MBR1020VL" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MBR1020VL" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Pattern "SRN3015", Attribute "Height" is a duplicate Attribute and will be deleted.

TextStyle count:  25
Padstack count:   11
Pattern count:    7
Symbol count:     6
Component count:  9

Export

