 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\58\\71\\5871052\\1\Eagle\2018-11-11_02-55-22\2018-11-11_02-55-22.xml
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX51p62Y11p45D0TSM2" renamed to "RX51p62Y11p45D0T"
Component "CL21C140JBANNNC" renamed to "CL21C140JBANNNC"
Component "TMK212BJ475KG-T" renamed to "TMK212BJ475KG-T"
Component "GRM155R61A475MEAAD" renamed to "GRM155R61A475MEAAD"
Component "WB_GND" renamed to "WB_GND"
Component "CBC2012T220M" renamed to "CBC2012T220M"
Component "RR1220P-823-D" renamed to "RR1220P-823-D"
Component "RR1220P-434-D" renamed to "RR1220P-434-D"
Component "CRCW0402100KFKED" renamed to "CRCW0402100KFKED"
Component "TPS62120DCNR" renamed to "TPS62120DCNR"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_PWL_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LOAD_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIM_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_STARTUP_VOLTAGE_SOURCE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PWL_CURRENT_LOAD was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX44Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX24Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX51p62Y11p45D0T" Shape(4) is a CIRCLE with no diameter.
Message - Pattern "DCN0008A", entity (3-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (5-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (11-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (13-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (16-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (18-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (21-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (23-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (30-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (32-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (35-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (37-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (40-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (42-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (45-Line) is a LINE with matching start and end points.
Message - Pattern "DCN0008A", entity (47-Line) is a LINE with matching start and end points.
Message - Component "CL21C140JBANNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C140JBANNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ475KG-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A475MEAAD" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A475MEAAD" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A475MEAAD" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A475MEAAD" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R61A475MEAAD" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CBC2012T220M" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CBC2012T220M" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CBC2012T220M" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-823-D" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-823-D" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-823-D" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-434-D" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-434-D" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RR1220P-434-D" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW0402100KFKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS62120DCNR" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS62120DCNR" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS62120DCNR" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS62120DCNR" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS62120DCNR" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TPS62120DCNR" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   4
Pattern count:    4
Symbol count:     19
Component count:  11

Export


Footprint "WB_GND" has no layer data mapped and will be skipped.
Component "WB_GND" requires footprint "WB_GND" and will be skipped.
Footprint "WB_BATTERY" has no layer data mapped and will be skipped.
Component "WB_BATTERY" requires footprint "WB_BATTERY" and will be skipped.
Footprint "WB_CURRENT_LOAD" has no layer data mapped and will be skipped.
Component "WB_CURRENT_LOAD" requires footprint "WB_CURRENT_LOAD" and will be skipped.
